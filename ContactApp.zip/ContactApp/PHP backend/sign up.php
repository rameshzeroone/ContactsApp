<!DOCTYPE html>
<html>
    <head>
        <center>
    <h1> SIGN UP </h1>
    <h3> Already have account ? <a href ="sign%20in.html">Sign in</a></h3>
        </center>
    </head>
    <body>
        <center>
    <form>
    <table>
    <tr> 
    <td> Email </td>
    <td> <input type= "mail" placeholder = "Email" Email=""></td>
    </tr>
    <tr>
    <td> password </td>
    <td> <input type= "password" placeholder = "password" name="">
    </td>
    </tr>
    <tr>
    <td> Secret code </td>
    <td> <input type= "code" placeholder = "code" name="">
    </td>
    </tr>
    <tr>
    <td> 
    <input type="button" value="SIGN UP" class="right">
    </td>
    </tr>
        <tr>
            <td> <input type="checkbox">By creating an account I agree <a href="#"> Terms and condition</a>
            </td>
        </tr>
    </table>
    </form>
    </center>
    </body>
</html>
