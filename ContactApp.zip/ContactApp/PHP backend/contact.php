<!DOCTYPE html>
<head>
    <title>CONTACT FORM</title>
</head>
<body>
<?php
include ("contact.php");
?>
    <h2> ADD CONTACTS</h2>
    <form>
    <table>
    <tr> 
    <td> Name </td>
    <td> <input type= "Name" placeholder = "Name" Name=""></td>
    </tr> 
    <tr>
    <td> Phone No </td>
    <td> <input type= "Phone No" placeholder = "phone No" name="">
    </td>
    </tr>
    <tr> 
    <td> Email </td>
    <td> <input type= "mail" placeholder = "Email" Email=""></td>
    </tr>
    <tr>
    <td> 
    <input type="button" value="SAVE" class="right">
    </td>   
    </tr>
        </table>
    </form>
</body>