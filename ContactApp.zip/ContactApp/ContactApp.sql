CREATE TABLE SIGN IN (
    id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Email varchar(225) NOT NULL,
    Passoword varchar(100)
) ENGINE=innoDB DEFAULT CHARSET=latin 1;

CREATE TABLE SIGN UP (
    id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Email varchar(225) NOT NULL,
    Passoword varchar(100)
	secret int(50)
) ENGINE=innoDB DEFAULT CHARSET=latin 1;

CREATE TABLE Add Contacts (
    id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Name varchar(225) NOT NULL,
    PhoneNo int(50)
	Email varchar(50)
) ENGINE=innoDB DEFAULT CHARSET=latin 1;





